# lebenswelt.github.io

ELPH Web Site
to be hosted at eagleslandingpethospital.com

Developed by Eric Lawson
Founder, EmptyRespon.se

CHANGELOG
Site not Live
-- Projected Live Date: Feb 1, 2017

January 31, 2017
--Article added as main page

January 1, 2017
--Site migrating from [Server 2052]@HomePi to GitHub Pages 
--Direct customer control and 100% uptime, at the cost of PHP support.

TODO
--fade bottom of bg.jpg
--final approval of footer
--import content for other pages
--import construction page
