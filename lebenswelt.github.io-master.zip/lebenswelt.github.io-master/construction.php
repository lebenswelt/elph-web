 <?php 
 include 'php/head.php';
 include 'php/menu_light.php';
 include 'php/intro.php';
 include 'php/contact.php';
 include 'php/footer.php';?>

<script src="http://eagleslandingpethospital.com/js/combo.js"></script>

</body>


