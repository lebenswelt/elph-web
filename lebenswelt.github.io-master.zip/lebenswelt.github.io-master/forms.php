 <?php 
    $INC_DIR = $_SERVER["DOCUMENT_ROOT"]. "/php/";
 include($INC_DIR. "head.php");
 include($INC_DIR. "construction.php");
 ?>
<h2>Commonly Used Forms</h2>
<a href="http://eagleslandingpethospital.com/resources/Estimate%20Agreement.pdf">Estimate Agreement</a>

<?php 
 include($INC_DIR. "contact.php");
 include($INC_DIR. "footer.php");?>

<script src="http://eagleslandingpethospital.com/js/combo.js"></script>

</body>


