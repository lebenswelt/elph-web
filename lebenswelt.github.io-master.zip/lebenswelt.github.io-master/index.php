 <?php 
    $INC_DIR = $_SERVER["DOCUMENT_ROOT"]. "/php/";
 include($INC_DIR. "head.php");
 include_once($INC_DIR. "analyticstracking.php"); 
 include($INC_DIR. "menu_light.php");
 include($INC_DIR. "intro.php");
 include($INC_DIR. "culture.php");
 include($INC_DIR. "innovation.php");
 include($INC_DIR. "careers.php");
 include($INC_DIR. "contact.php");
 include($INC_DIR. "footer.php");?>

<script src="http://eagleslandingpethospital.com/js/combo.js"></script>

</body>