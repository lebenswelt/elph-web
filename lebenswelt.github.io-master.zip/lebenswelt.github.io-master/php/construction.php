    <div id="intro" class="section intro">
        
<div class="heading">
    <h2>Eagles Landing Pet Hospital</h2>
    <!--[if gt IE 9]><!-->
        <img class="intro-logo" src="http://eagleslandingpethospital.com/resources/ELPH_logo.png" width="635" height="292"/>
    <!--<![endif]-->
</div>

<div class="content">
    <h3>Check back soon!</h3>
    <div class="column">
        <img src="http://eagleslandingpethospital.com/resources/404.jpg" width="383" height="306">
    </div>
    <div class="column">
        <p><strong>This page is currently under construction.</strong></p>
	<p>Very soon this page will introduce you to our wonderful staff and available services.</p>
    </div>

</div>

    </div>

