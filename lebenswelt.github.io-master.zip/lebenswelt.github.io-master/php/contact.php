    <div id="contact" class="section contact">
            
<div class="heading">
    <h2><span>MORE INFORMATION<br class="w1024 w640">COMING SOON.</span></h2>
</div>

<div class="content">

    <h3>Contact</h3>

    <div class="column web">

        <div class="pr">
            <strong>Visit us on Facebook</strong><br class="w1024"> <a href="https://www.facebook.com/Eagles-Landing-Pet-Hospital-118753188199840">Eagles Landing Pet Hospital</a>
        </div>

        <div class="pr">
<strong>Visit us in person</strong>
<p>Mon-Fri: 7:00 am - 6:00 pm </p>
<p>&emsp;&emsp; Sat: 9:00 am - 3:00 pm</p>
	</div>
    

    </div>

    <div class="column real">
        <div class="address">
            <div>Eagles Landing Pet Hospital, PLLC.</div>
            <div>330 W 1st St.</div>
            <div>Morehead, KY 40351</div>
	    <div>(606) 780-0208</div>
	    <div>&emsp;</div>

            <iframe src="https://www.google.com/maps/embed?pb=!1m0!3m2!1sen!2sus!4v1456409758272!6m8!1m7!1spBJ9cnOXOATGNJQp9wzpBQ!2m2!1d38.17747372209063!2d-83.43672523587489!3f69.79127119690324!4f-2.415149642411734!5f2.299968626952992" width="550" height="250" frameborder="0" style="border:0" allowfullscreen></iframe>
	

        </div>


    </div>

</div>

    </div>
