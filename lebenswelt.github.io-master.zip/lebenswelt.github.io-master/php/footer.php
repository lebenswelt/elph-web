    <div id="footer" class="section content">

    <div id="fb-root"></div>

<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script> 

        <div class="logos">
            <!--[if lt IE 10]><img src="http://eagleslandingpethospital.com/resources/ELPH_logo.png" width="92" height="39"><![endif]-->
            <!--[if gt IE 9]><!--><img src="http://eagleslandingpethospital.com/resources/ELPH_logo.png" width="92" height="39"><!--<![endif]-->
           </div>

        <ul id="legal-documentation" class="links">
            <li class="privacy-policy"><a href="privacy-policy.html">Privacy Policy</a></li>
            <li class="legal"><a href="legal-documentation.html">Legal Documentation</a></li>
            <li class="legal-docs hidden">
                <h2>Legal Documentation</h2>
                <ul>
                    <li><a href="website-terms-of-use.html">Website Terms of Use</a></li>
                    <li><a href="privacy-policy.html">Privacy Policy</a></li>
		</ul>
		<li class="fb-spacer"><p>&emsp;|&emsp;</p></li>     
	<li class="social-media"> <div class="fb-like" data-href="https://www.facebook.com/Eagles-Landing-Pet-Hospital-118753188199840" data-layout="button_count" data-action="like" data-show-faces="true" data-share="true"></div></li>     
            
        </ul>

        <small>
            Some logos and designs are trademarks or registered trademarks of Eagles Landing Pet Hospital, PLLC.
            Some logos and designs are trademarks or registered trademarks of Eric Lawson.
            All other trademarks are the property of their respective owners.
        </small>

    </div>
