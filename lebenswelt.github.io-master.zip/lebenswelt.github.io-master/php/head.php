<html>
<head>
    <title>Eagles Landing Pet Hospital, PLLC</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=641, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">

    <link rel="stylesheet" href="http://eagleslandingpethospital.com/quotes.css">

<link rel="icon" type="image/vnd.microsoft.icon" href="http://eagleslandingpethospital.com/resources/ELPH_logo.ico">

</head>
<body>

