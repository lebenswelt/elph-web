    <div id="intro" class="section intro">
        
<div class="heading">
    <h2>Eagles Landing Pet Hospital</h2>
    <!--[if gt IE 9]><!-->
        <img class="intro-logo" src="http://eagleslandingpethospital.com/resources/ELPH_logo.png" width="635" height="292"/>
    <!--<![endif]-->
</div>

<div class="content">
    <h3><?php include($INC_DIR. "content/intro%20h1.txt") ?></h3>
    <div class="column">
        <img src="http://eagleslandingpethospital.com/resources/404.jpg" width="383" height="306">
    </div>
    <div class="column">
        <p><strong>
			<?php include($INC_DIR. "content/intro%20strong.txt") ?>
			</strong></p>
	<p>
	<?php include($INC_DIR. "content/intro%20p1.txt") ?>
	</p>
    </div>

</div>

    </div>

