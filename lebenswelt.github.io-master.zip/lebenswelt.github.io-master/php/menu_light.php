<div id="header">
    <ul class="menu">
        <li class="menu-item first"><a href="#culture"> </a></li>
        <li class="menu-item second"><a href="#innovation"> </a></li>
        <li class="menu-logo">
               <!--[if lt IE 10]><img src="resources/ELPH_logo.png" width="39" height="39"><![endif]-->
            <!--[if gt IE 9]><!--><img src="resources/ELPH_logo.png" width="39" height="39"><!--<![endif]-->
        </li>
        <li class="menu-item fourth"><a href="#contact"> </a></li>
        <li class="menu-item third"><a href="#careers"> </a></li>
	

        <li class="menu-top">
            <a href="#intro"><img src="resources/top_arrow.png" width="61" height="61"></a>
        </li>

    </ul>
</div>