<?php
 phpinfo();
 ?>