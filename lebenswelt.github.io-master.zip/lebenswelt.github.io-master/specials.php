 <?php 
    $INC_DIR = $_SERVER["DOCUMENT_ROOT"]. "/php/";
 include($INC_DIR. "head.php");
 include_once($INC_DIR. "analyticstracking.php"); 
 include($INC_DIR. "menu.php");
 include($INC_DIR. "construction.php");
 include($INC_DIR. "contact.php");
 include($INC_DIR. "footer.php");?>

<script src="http://eagleslandingpethospital.com/js/combo.js"></script>

</body>


